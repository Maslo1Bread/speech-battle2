(Version of "Quill and Antler" with expanded horizontal form.)

A fantasy/medieval style pixel font that draws inspiration from various sources.